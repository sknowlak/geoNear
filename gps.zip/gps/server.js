
const express = require("express");
const app = express();
app.use(express.json());
require("./db/connection.js")
app.get("/",(req,res)=>
{
    res.json({
        message:"Welcome to our website"
    });
});
require("./app/routes/route.js")(app)

app.listen(3002,()=>{
    console.log('Listening port on 3002');
})

