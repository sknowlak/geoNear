
const {Provider,User}=require('../models/model.js')
exports.saveLocation=async(req,res)=>{
    try{

        console.log(req.body.address)
        const obj=new Provider({
            name:req.body.name,
            address:{

            street:req.body.address.street,
            number:req.body.address.number,
            city:req.body.address.city,
            zipCode:req.body.address.zipCode,
            location:{

                type:req.body.address.location.type,
                coordinates:req.body.address.location.coordinates
            }
         }
        })
       const result=await obj.save() ;
            if(result){
            console.log("1 document inserted");
            res.send({message:"data add successfully",result})
        }
    
    }catch(error){
        console.log(error)
        res.send({message:"somthing Error"})
    }
}


//userStore Location
exports.userSaveLocation=async(req,res)=>{
        try{
    
            console.log(req.body.address)
            const obj=new User({
                name:req.body.name,
                maxDistance:req.body.maxDistance ,
                address:{

                street:req.body.address.street,
                number:req.body.address.number,
                city:req.body.address.city,
                zipCode:req.body.address.zipCode,
                location:{

                    type:req.body.address.location.type,
                    coordinates:req.body.address.location.coordinates
                }
             }
            })
           const result=await obj.save() ;
                if(result){
                console.log("1 document inserted");
                res.send({message:"data add successfully",result})
            }
        
        }catch(error){
            console.log(error)
            res.send({message:"somthing Error"})
        }
    
}

exports.findLocation=async(req,res)=>{
    try{
        const id=req.params._id
        const user=await User.findOne({_id:id})
        console.log(user)
        const coordinates=user.address.location.coordinates
       const maxdistance=user.maxDistance
       // console.log(coordinates,maxdistance)
        //Store.statics.findByCoordinates = function(coordinates, maxDistance) {
            const result=await Provider.aggregate([{
              $geoNear: {
                near: {
                  type: "Point",
                  coordinates: coordinates
                },
                maxDistance: maxdistance,
                distanceField: "dist.calculated",
                spherical: true
              }
            }]);
            console.log(result);
            if(result!=0){
                res.send(result)
            }
          else{
              res.status(404).send("No location found")
          }
    }
    catch(error){
        console.log(error)
    }
}