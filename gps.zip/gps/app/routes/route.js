module.exports = (app)=>{
    const gps = require("../controllers/controller.js");

    app.post("/provider",gps.saveLocation);
    app.post("/user",gps.userSaveLocation);
    app.get("/user/:_id",gps.findLocation);
}

