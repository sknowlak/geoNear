const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define the Store schema
const ProviderSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  address: {
    street: String,
    number: Number,
    city: {
      type: String,
      required: true
    },
    zipCode: {
      type: String,
      required: true
    },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point"
      },
      coordinates: {
        type: [Number],
        default: [0, 0]
      }
    }
  },
  createdOn: {
    type: Date,
    default: Date.now
  },
  updatedOn: {
    type: Date,
    default: Date.now
  }
});
ProviderSchema.index({
    "address.location": "2dsphere"
  });






  const UserSchema = new Schema({
    name: {
      type: String,
      required: true
    },
    maxDistance:{
      type:Number,
      required:true
    },
    address: {
      street: String,
      number: Number,
      city: {
        type: String,
        required: true
      },
      zipCode: {
        type: String,
        required: true
      },
      location: {
        type: {
          type: String,
          enum: ["Point"],
          default: "Point"
        },
        coordinates: {
          type: [Number],
          default: [0, 0]
        }
      }
    },
    createdOn: {
      type: Date,
      default: Date.now
    },
    updatedOn: {
      type: Date,
      default: Date.now
    }
  });
  UserSchema.index({
      "address.location": "2dsphere"
    });

  const Provider=mongoose.model('provider',ProviderSchema)
  const User=mongoose.model('user',UserSchema)
  module.exports ={Provider,User}