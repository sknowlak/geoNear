
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/gps2",{
   // useNewUrlParser:true,
    //useCreateIndex:true,
    //useUnifiedTopology:true,
    //useFindAndModify:true

}).then(()=>{
    console.log("Connection successful");
}).catch((err)=>{
    console.log("Not connected");
})





